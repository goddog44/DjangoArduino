from django.urls import path
from arduino import views

app_name = 'arduino'

urlpatterns = [
    path('arduino/<str:serial_number>/', views.valuesAPI, name='valuesAPI'),
    # path('get_csrf_token/', views.get_csrf_token, name='get_csrf_token'),
    # ... other endpoints
]