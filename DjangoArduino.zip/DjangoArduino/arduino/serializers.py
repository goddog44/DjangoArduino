from rest_framework import serializers
from arduino.models import Values

class ValuesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Values
        fields = '__all__'
