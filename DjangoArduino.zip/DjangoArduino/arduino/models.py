from django.db import models

class Values(models.Model):
    Temperature = models.CharField(max_length=500)
    Humidity = models.CharField(max_length=500)
    Current1 = models.CharField(max_length=500)
    Current2 = models.CharField(max_length=500)
    Tension1 = models.CharField(max_length=500)
    Tension2 = models.CharField(max_length=500)
    Power = models.CharField(max_length=500)
    data = models.CharField(max_length=255)
    # Other fields in your model