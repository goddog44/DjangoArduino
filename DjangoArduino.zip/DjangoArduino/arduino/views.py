# # from django.shortcuts import render
# # import serial

# # # Create your views here.
# # def index(request):
# #     ser = serial.Serial("COM3", 9600)
# #     data = ser.readline().decode().strip()
# #     ser.close()
# #     return render(request, "index.html", {
# #         "data": data
# #     })

from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from arduino.models import Values
from arduino.serializers import ValuesSerializer

@csrf_exempt
def valuesAPI(request, serial_number):
    if request.method == 'GET':
        values = Values.objects.all()
        values_serializer = ValuesSerializer(values, many=True)
        return JsonResponse(values_serializer.data, safe=False)
    elif request.method == 'POST':
        temperature = request.POST.get('temperature', None)
        humidity = request.POST.get('humidity', None)
        data = request.POST.get('data', None)
        current1 = request.POST.get('current1', None)
        current2 = request.POST.get('current2', None)
        tension1 = request.POST.get('tension1', None)
        power = request.POST.get('power', None)
        tension2 = request.POST.get('tension2', None)
        
        
        if temperature is not None and humidity is not None and current1 is not None and current2 is not None and tension1 is not None and current2 is not None and power is not None and data is not None:
            # Process sensor data as needed (e.g., store in database)
            return JsonResponse({'message': 'Sensor data received'}, status=200)
    
    return JsonResponse({'error': 'Invalid request'}, status=400)









    


#     # elif request.method == 'PUT':
#     #     department_data= JSONParser().parse(request)
#     #     department=Department.objects.get(DepartmentId=department_data['Department'])
#     #     departments_serializer=DepartmentSerializers(department,fdata=department_data)
#     #     if departments_serializer.is_valid():
#     #         departments_serializer.save()
#     #         return JsonResponse("Update succesfully", safe=False)
#     #     return JsonResponse("Failed to Update")
#     # elif request.method == 'DELETE':
#     #     department=Department.objects.get(DepartmentId=Id)
#     #     department.delete()
#     # return JsonResponse("Delete Succesfully",safe=False)

# from django.http import JsonResponse
# from django.views.decorators.csrf import csrf_exempt
# from .models import SensorData
# import json

# @csrf_exempt
# def valuesAPI(request, serial_number):
#     if request.method == 'POST':
#         data = request.POST
#         temperature = data.get('temparature')
#         humidity = data.get('humidity')
#         current1 = data.get('current1')
#         tension1 = data.get('tension1')
#         current2 = data.get('current2')
#         tension2 = data.get('tension2')
#         power = data.get('power')

#         # Process the received data as needed

#         response_data = {'message': 'Data received successfully'}
#         return JsonResponse(response_data)
#     else:
#         response_data = {'error': 'Invalid request method'}
#         return JsonResponse(response_data, status=405)